#~/bin/sh
gcc -g -o mini_crack mini_crack.c -lcrypt
