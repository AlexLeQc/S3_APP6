#!/bin/sh
./mini_crack -xl 2 -xc caracteres -sh shadow -dict mots_de_passe

