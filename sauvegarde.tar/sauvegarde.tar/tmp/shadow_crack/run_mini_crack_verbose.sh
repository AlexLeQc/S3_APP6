#!/bin/sh
./mini_crack -v -xl 2 -xc caracteres -sh shadow -dict mots_de_passe

