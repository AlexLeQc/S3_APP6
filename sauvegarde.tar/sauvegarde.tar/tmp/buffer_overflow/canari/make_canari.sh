#!/bin/sh
gcc -g -o test_buf_canari test_buf_canari.c

