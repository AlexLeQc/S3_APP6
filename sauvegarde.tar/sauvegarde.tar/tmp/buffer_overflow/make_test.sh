#!/bin/sh
gcc -g -o test_buf test_buf.c

